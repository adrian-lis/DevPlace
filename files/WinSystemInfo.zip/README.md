# WinSystemInfo

WinSystemInfo is a Windows system information and auditing tool that helps you inspect your computer's hardware, network configuration, Windows services, security settings, event logs, storage devices, USB devices, startup entries, and other system information.

## Getting Started

1. Download `WinSystemInfo-release.zip`.

2. Right-click the downloaded ZIP file and select **Extract All...**.

3. Choose a destination folder and click **Extract**.

4. Open the extracted folder.

5. Double-click `WinSystemInfo.exe` to launch the application.

**No  installation is required.**

Some features may require administrator privileges to access additional system information.

## Files Included

- `WinSystemInfo.exe` — the application.

- `SHA256SUMS.txt` — the SHA-256 checksum of the executable.

- `README.md` — this user guide.

- `LICENSE` — license and disclaimer.

## Verify the Download (SHA-256)

SHA-256 verification lets you check whether the executable matches the checksum published by the project maintainer.

### Step 1: Open PowerShell

1. Open the folder containing `WinSystemInfo.exe`.

2. Click the address bar in File Explorer.

3. Type `powershell` and press **Enter**.

### Step 2: Calculate the Checksum

Run this command:

```
Get-FileHash .\WinSystemInfo.exe -Algorithm SHA256
```

PowerShell will display the SHA-256 hash of the executable.

### Step 3: Compare the Hash

Open `SHA256SUMS.txt` and compare its published hash with the value displayed by PowerShell.

The two values must match exactly.

- **Hashes match:** The executable matches the file represented by the published checksum.

- **Hashes do not match:** Do not run the executable. Download it again from the official source and check the hash once more.

**Important:** For meaningful verification, obtain the expected checksum from the project's official release page, separately from the downloaded ZIP. A checksum stored only inside the same ZIP does not independently prove that the download is authentic.

## Windows Security

Windows may display a security warning when an application is downloaded from the Internet or is not signed with a recognized publisher certificate.

Only run the application if you trust its [Source Code](https://github.com/adrian-lis/WinSystemInfo). Verify the checksum before running it if a trusted checksum is available.

A matching checksum does not guarantee that software is safe or free of bugs.

## License and Disclaimer

WinSystemInfo is provided under the license included in the `LICENSE` file.

The software is provided "AS IS", without warranties of any kind, to the maximum extent permitted by applicable law. Use it at your own risk. The authors and contributors disclaim liability for damage, data loss, or other consequences arising from the use of the software, to the extent permitted by applicable law.
